Basic QR encoder.

go get [-u] rsc.io/qr
