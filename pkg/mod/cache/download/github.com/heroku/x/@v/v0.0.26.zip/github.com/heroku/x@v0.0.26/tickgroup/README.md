# tickgroup

A tickgroup is a collection of goroutines that are spawned to call a subtask
every set interval.

## Documentation

Full documentation is available on [godoc](https://godoc.org/github.com/heroku/x/tickgroup).
